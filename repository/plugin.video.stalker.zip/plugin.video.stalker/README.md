# plugin.video.stalker

Kodi Stalker video add-on - all platforms

Forum
http://iptvtalk.org/showthread.php?2514-Kodi-Stalker-video-add-on-all-platforms
